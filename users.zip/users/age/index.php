<?php

header('Content-Type: application/json; charset=utf-8');
require '../config.php';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $data = json_decode(file_get_contents("php://input"));
  $firstName = $data->namaDepan;
  $lastName = $data->namaBelakang;
  $tglLahir = $data->tanggalLahir;
  // $date = date('Y-m-d H:i:s', time());
  // echo $date;

  $tanggalLahir = strtotime($tglLahir);

  $today = new DateTime('today');
  $birthFormat = date('Y-m-d', $tanggalLahir);
  $dateFormat = date('d-m-Y', $tanggalLahir);
  $birthDay = new DateTime($birthFormat);


  $response = [
    'namaLengkap' => $firstName . ' ' . $lastName,
    'tanggalLahir' => $dateFormat,
    'umur' => $today->diff($birthDay)->y . ' Tahun'
  ];

  echo json_encode($response);
} else {
  $response = [
    'status' => 'error',
    'message' => 'Invalid method request'
  ];
  echo json_encode($response);
}
